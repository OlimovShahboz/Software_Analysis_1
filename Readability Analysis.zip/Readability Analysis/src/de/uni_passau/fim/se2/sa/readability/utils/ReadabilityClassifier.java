package de.uni_passau.fim.se2.sa.readability.utils;

public class ReadabilityClassifier {
    public void trainAndEvaluate() {
        System.out.println("Training model...");
        // Stubbed logic for training and evaluation
    }

    public String classify(String snippet) {
        return "EASY"; // Stub default classification
    }
}
