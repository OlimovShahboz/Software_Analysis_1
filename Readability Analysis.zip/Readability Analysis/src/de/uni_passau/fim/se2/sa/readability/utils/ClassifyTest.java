package de.uni_passau.fim.se2.sa.readability.utils;

public class ClassifyTest {
}
