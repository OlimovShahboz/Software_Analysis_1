package de.uni_passau.fim.se2.sa.readability.utils;

import java.util.List;

public class DatasetLoader {
    public List<String> loadDataset() {
        System.out.println("Loading dataset...");
        return List.of("public class A {}", "public class B {}"); // Stubbed data
    }
}
