package de.uni_passau.fim.se2.sa.readability.features;

import static org.junit.jupiter.api.Assertions.*;

class NumberLinesFeatureTest {




}